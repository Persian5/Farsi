"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ChevronRight } from "lucide-react"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"

export default function HomePage() {
  const [quizAnswer, setQuizAnswer] = useState<string | null>(null)
  const [quizSubmitted, setQuizSubmitted] = useState(false)
  const [progressValue, setProgressValue] = useState(0)
  const correctAnswer = "salaam"

  // Animate progress bar on page load
  useEffect(() => {
    const timer = setTimeout(() => {
      setProgressValue(33)
    }, 500)
    return () => clearTimeout(timer)
  }, [])

  const handleQuizSubmit = () => {
    setQuizSubmitted(true)
  }

  const scrollToWaitlist = () => {
    document.getElementById("waitlist")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Navbar */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center justify-between px-4 sm:px-6 md:px-8">
          <Link href="/" className="flex items-center gap-2 font-bold text-base sm:text-lg text-primary">
            <span className="hidden sm:inline">Iranopedia Farsi Academy</span>
            <span className="sm:hidden">Iranopedia Farsi Academy</span>
          </Link>
          <Button size="sm" className="bg-accent hover:bg-accent/90 text-white">
            Start Now
          </Button>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-primary/10 py-10 sm:py-14 px-4 sm:px-6 md:px-8">
          <div className="w-full">
            <div className="flex flex-col items-center text-center">
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-primary mb-6">
                Learn Farsi. Reconnect with Your Roots.
              </h1>
              <p className="text-lg sm:text-xl text-muted-foreground w-full max-w-3xl mb-8">
                Bite-sized lessons, real culture, zero pressure.
              </p>

              <div className="flex flex-col items-center gap-4 mb-10">
                <div className="flex gap-5 text-5xl sm:text-6xl md:text-7xl">
                  <span>IRAN</span>
                  <span>❤️</span>
                  <span>📱</span>
                </div>
                <p className="text-sm sm:text-base text-muted-foreground">Connect with your heritage</p>
              </div>

              <Button
                size="lg"
                className="mt-2 bg-accent hover:bg-accent/90 text-white transition-all duration-300 hover:scale-105 hover:shadow-lg rounded-full px-10 py-7 text-xl"
                onClick={() => document.getElementById("lesson-1")?.scrollIntoView({ behavior: "smooth" })}
              >
                ▶️ Start Lesson 1
              </Button>
            </div>
          </div>
        </section>

        {/* Feature Cards */}
        <section className="py-10 sm:py-14 px-4 sm:px-6 md:px-8 bg-white">
          <div className="w-full">
            <div className="grid gap-4 sm:gap-6 md:grid-cols-3">
              <Card className="border-primary/20 shadow-sm hover:shadow-md transition-shadow rounded-xl">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-3 text-lg sm:text-xl">
                    <span className="text-2xl sm:text-3xl">📚</span> Bite-sized Lessons
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-base sm:text-lg">
                    Learn Farsi in 5-minute chunks that fit into your busy schedule.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-primary/20 shadow-sm hover:shadow-md transition-shadow rounded-xl">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-3 text-lg sm:text-xl">
                    <span className="text-2xl sm:text-3xl">🍚</span> Real Iranian Culture
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-base sm:text-lg">From tahdig to Nowruz, learn language in its cultural context.</p>
                </CardContent>
              </Card>

              <Card className="border-primary/20 shadow-sm hover:shadow-md transition-shadow rounded-xl">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-3 text-lg sm:text-xl">
                    <span className="text-2xl sm:text-3xl">✍️</span> Finglish + Persian
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-base sm:text-lg">Start in Latin letters, move to Persian script when ready.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Progress Tracker */}
        <section className="py-10 sm:py-14 px-4 sm:px-6 md:px-8 bg-primary/5">
          <div className="w-full">
            <h2 className="text-2xl sm:text-3xl font-bold mb-6 text-primary">Your Progress</h2>
            <Progress value={progressValue} className="h-5 mb-4 transition-all duration-1000 ease-in-out" />
            <p className="text-base sm:text-lg text-muted-foreground">Earn XP, badges, and streaks while you learn.</p>
          </div>
        </section>

        {/* Badge Preview */}
        <section className="py-10 sm:py-14 px-4 sm:px-6 md:px-8 bg-white">
          <div className="w-full">
            <h2 className="text-2xl sm:text-3xl font-bold mb-6 sm:mb-8 text-primary">🎖️ Badge Preview</h2>
            <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
              <Card className="shadow-sm hover:shadow-md transition-shadow rounded-xl overflow-hidden">
                <CardHeader className="pb-3 bg-primary/5">
                  <CardTitle className="text-lg sm:text-xl flex items-center gap-3">
                    <span>👨‍👩‍👧‍👦</span> Mehmooni Ready
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-4">
                  <p className="text-base text-muted-foreground">
                    You can now introduce yourself at Persian gatherings
                  </p>
                </CardContent>
                <CardFooter>
                  <Badge variant="outline" className="bg-accent/10 text-accent text-sm">
                    Beginner
                  </Badge>
                </CardFooter>
              </Card>

              <Card className="shadow-sm hover:shadow-md transition-shadow rounded-xl overflow-hidden">
                <CardHeader className="pb-3 bg-primary/5">
                  <CardTitle className="text-lg sm:text-xl flex items-center gap-3">
                    <span>🍚</span> Tahdig Lover
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-4">
                  <p className="text-base text-muted-foreground">You've learned Persian food vocab</p>
                </CardContent>
                <CardFooter>
                  <Badge variant="outline" className="bg-primary/10 text-primary text-sm">
                    Cultural
                  </Badge>
                </CardFooter>
              </Card>

              <Card className="shadow-sm hover:shadow-md transition-shadow rounded-xl overflow-hidden sm:col-span-2 lg:col-span-1">
                <CardHeader className="pb-3 bg-primary/5">
                  <CardTitle className="text-lg sm:text-xl flex items-center gap-3">
                    <span>🎉</span> Nowruz Novice
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-4">
                  <p className="text-base text-muted-foreground">You unlocked your first cultural story</p>
                </CardContent>
                <CardFooter>
                  <Badge variant="outline" className="bg-blue-500/10 text-blue-500 text-sm">
                    Advanced
                  </Badge>
                </CardFooter>
              </Card>
            </div>
          </div>
        </section>

        {/* Lesson Block */}
        <section id="lesson-1" className="py-10 sm:py-14 px-4 sm:px-6 md:px-8 bg-accent/5">
          <div className="w-full">
            <h2 className="text-2xl sm:text-3xl font-bold mb-6 sm:mb-8 text-accent">
              🟣 Lesson 1 – Say Hi Like a Persian
            </h2>

            <div className="space-y-5">
              <Card className="shadow-sm hover:shadow-md transition-shadow overflow-hidden rounded-xl">
                <CardHeader className="pb-3 bg-primary/5">
                  <CardTitle className="text-lg sm:text-xl text-primary">Hello / Hi</CardTitle>
                </CardHeader>
                <CardContent className="pt-4 pb-6">
                  <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-4">
                    <div className="text-base font-medium text-muted-foreground px-2 sm:px-3 py-2 bg-gray-100 rounded">
                      English
                    </div>
                    <div className="text-base font-medium text-muted-foreground px-2 sm:px-3 py-2 bg-gray-100 rounded">
                      Finglish
                    </div>
                    <div className="text-base font-medium text-muted-foreground px-2 sm:px-3 py-2 bg-gray-100 rounded">
                      Persian
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 sm:gap-3 items-center">
                    <div className="text-base sm:text-lg px-2 sm:px-3 py-2">Hello</div>
                    <div className="text-base sm:text-lg px-2 sm:px-3 py-2">Salaam</div>
                    <div className="text-base sm:text-lg font-persian px-2 sm:px-3 py-2 font-bold text-primary">
                      سلام
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-sm hover:shadow-md transition-shadow overflow-hidden rounded-xl">
                <CardHeader className="pb-3 bg-primary/5">
                  <CardTitle className="text-lg sm:text-xl text-primary">How are you?</CardTitle>
                </CardHeader>
                <CardContent className="pt-4 pb-6">
                  <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-4">
                    <div className="text-base font-medium text-muted-foreground px-2 sm:px-3 py-2 bg-gray-100 rounded">
                      English
                    </div>
                    <div className="text-base font-medium text-muted-foreground px-2 sm:px-3 py-2 bg-gray-100 rounded">
                      Finglish
                    </div>
                    <div className="text-base font-medium text-muted-foreground px-2 sm:px-3 py-2 bg-gray-100 rounded">
                      Persian
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 sm:gap-3 items-center">
                    <div className="text-base sm:text-lg px-2 sm:px-3 py-2">How are you?</div>
                    <div className="text-base sm:text-lg px-2 sm:px-3 py-2">Chetori?</div>
                    <div className="text-base sm:text-lg font-persian px-2 sm:px-3 py-2 font-bold text-primary">
                      چطوری؟
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-accent/20 bg-accent/5 shadow-sm rounded-xl">
                <CardContent className="py-6 px-4 sm:px-6">
                  <div className="flex gap-4 items-start">
                    <span className="text-3xl">🌸</span>
                    <div>
                      <p className="font-medium text-lg mb-2">Grandma Tip:</p>
                      <p className="text-base">
                        In Iran, even strangers say salaam. It's polite <em>and</em> warm.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Interactive Quiz */}
              <Card className="shadow-sm rounded-xl">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg sm:text-xl text-primary">Quick Quiz</CardTitle>
                  <CardDescription className="text-base mt-2">
                    Choose the correct translation for "Hello"
                  </CardDescription>
                </CardHeader>
                <CardContent className="pb-6">
                  <RadioGroup value={quizAnswer || ""} onValueChange={setQuizAnswer} className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem
                        value="salaam"
                        id="salaam"
                        className={quizSubmitted && quizAnswer === "salaam" ? "border-green-500 text-green-500" : ""}
                      />
                      <Label
                        htmlFor="salaam"
                        className={`text-lg ${quizSubmitted && quizAnswer === "salaam" ? "text-green-600 font-medium" : ""}`}
                      >
                        Salaam
                      </Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem
                        value="chetori"
                        id="chetori"
                        className={quizSubmitted && quizAnswer === "chetori" ? "border-red-500 text-red-500" : ""}
                      />
                      <Label
                        htmlFor="chetori"
                        className={`text-lg ${quizSubmitted && quizAnswer === "chetori" ? "text-red-600" : ""}`}
                      >
                        Chetori
                      </Label>
                    </div>
                    <div className="flex items-center space-x-3">
                      <RadioGroupItem
                        value="merci"
                        id="merci"
                        className={quizSubmitted && quizAnswer === "merci" ? "border-red-500 text-red-500" : ""}
                      />
                      <Label
                        htmlFor="merci"
                        className={`text-lg ${quizSubmitted && quizAnswer === "merci" ? "text-red-600" : ""}`}
                      >
                        Merci
                      </Label>
                    </div>
                  </RadioGroup>

                  {quizSubmitted && (
                    <div
                      className={cn(
                        "mt-6 p-4 rounded-md text-base",
                        quizAnswer === correctAnswer ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800",
                      )}
                    >
                      {quizAnswer === correctAnswer
                        ? "✅ Correct! Salaam means Hello in Farsi."
                        : "❌ Incorrect. Try Again."}
                    </div>
                  )}
                </CardContent>
                <CardFooter className="border-t bg-gray-50 flex justify-center py-4">
                  <Button
                    onClick={handleQuizSubmit}
                    disabled={!quizAnswer}
                    className="w-full sm:w-auto bg-primary hover:bg-primary/90 px-10 py-6 text-lg"
                  >
                    Submit Answer
                  </Button>
                </CardFooter>
              </Card>

              {/* Coming Up Next Section */}
              <Card className="shadow-sm rounded-xl border-primary/20 bg-primary/5">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg sm:text-xl text-primary flex items-center gap-3">
                    <span>🔮</span> Coming Up Next
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-5 pb-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-white rounded-full p-2 shadow-sm flex items-center justify-center w-14 h-14 shrink-0">
                      <span className="text-2xl">🧮</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-lg mb-1">Lesson 2: Numbers 1–10</h4>
                      <p className="text-base text-muted-foreground">Count like a Persian</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-white rounded-full p-2 shadow-sm flex items-center justify-center w-14 h-14 shrink-0">
                      <span className="text-2xl">👪</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-lg mb-1">Lesson 3: Family Words</h4>
                      <p className="text-base text-muted-foreground">Learn to introduce your family</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-white rounded-full p-2 shadow-sm flex items-center justify-center w-14 h-14 shrink-0">
                      <span className="text-2xl">🎁</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-lg mb-1">Bonus: Cultural Insights</h4>
                      <p className="text-base text-muted-foreground">Unlock special rewards as you progress</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="py-4">
                  <Button
                    variant="outline"
                    className="w-full justify-between group hover:bg-primary/10 py-6 text-lg"
                    onClick={scrollToWaitlist}
                  >
                    Continue Learning
                    <ChevronRight className="h-6 w-6 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer id="waitlist" className="bg-green-50 py-10 sm:py-14 px-4 sm:px-6 md:px-8 mt-6">
        <div className="w-full">
          <div className="grid gap-10 md:grid-cols-2 text-center md:text-left">
            <div>
              <h3 className="text-2xl sm:text-3xl font-bold mb-6 text-primary">Iranopedia Farsi Academy Beta</h3>
              <p className="text-primary mb-6 text-lg">Learn Farsi Online</p>
              <p className="text-base text-gray-600 max-w-md mx-auto md:mx-0">
                Made for anyone reconnecting with Persian roots — no pressure, just love.
              </p>

              <div className="flex gap-8 mt-8 justify-center md:justify-start">
                <Link
                  href="https://instagram.com"
                  className="text-3xl hover:opacity-80 transition-opacity"
                  aria-label="Instagram"
                >
                  📸
                </Link>
                <Link
                  href="https://tiktok.com"
                  className="text-3xl hover:opacity-80 transition-opacity"
                  aria-label="TikTok"
                >
                  🎵
                </Link>
              </div>
            </div>

            <div className="mt-6 md:mt-0">
              <div className="bg-white p-6 sm:p-8 rounded-xl shadow-sm">
                <h3 className="text-xl sm:text-2xl font-medium mb-6 text-primary">Join the Waitlist</h3>
                <div className="flex flex-col sm:flex-row gap-3 mx-auto md:mx-0">
                  <Input
                    type="email"
                    placeholder="Your email"
                    className="border-primary/20 focus:border-primary py-6 text-lg"
                  />
                  <Button className="bg-accent hover:bg-accent/90 text-white py-6 text-lg">Join</Button>
                </div>
              </div>

              <div className="mt-8 text-center md:text-left">
                <Link
                  href="https://iranopedia.com"
                  className="inline-block bg-primary/10 hover:bg-primary/20 text-primary px-8 py-4 rounded-full text-lg transition-colors"
                >
                  Visit Iranopedia.com
                </Link>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
